package Karate.Demo;

import com.intuit.karate.junit5.Karate;

public class TestRunner {
	@Karate.Test
    Karate testSample() {
        return Karate.run("TestCase15").relativeTo(getClass());
    }
}

package com.ugtf.prism;

public class UGTFapi {

	public void endExecution() {
		// TODO Auto-generated method stub
		
	}

}

package com.qa.reporters;

public class ExtentReporter {

}

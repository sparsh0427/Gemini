package com.qa.reporters;

public class BatchReporter {

	public static String testFolder;

	public static void appendrow(String methodname, String status, String steps, String description, String time,
			String screenShot) {
		// TODO Auto-generated method stub
		
	}

	public static void writeFailInReport(String methodname, String status, String description, String string,
			String screenShot) {
		// TODO Auto-generated method stub
		
	}

}

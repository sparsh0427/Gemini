package com.qa.dataProviders;

public class CommonDataProvider {

	public static void getClassToRunFlag(String string) {
		
	}

}

package com.qa.listeners;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.testng.IAlterSuiteListener;
import org.testng.ITestContext;
import org.testng.xml.XmlSuite;

import com.qa.genericLib.OpenAndCloseBrowser;



public class PropertyInjectorListener implements IAlterSuiteListener {
	public static String ProjectName, dirPath;
	public void alter (List<XmlSuite> suites, ITestContext testContext) {
		ProjectName = testContext.getSuite().getParameter(ProjectName);
		ProjectName=OpenAndCloseBrowser.P_Name;
		dirPath =testContext.getSuite().getParameter(dirPath);
		dirPath = OpenAndCloseBrowser.dir_Path;
		XmlSuite suite = suites.get (0);
		Properties properties = new Properties();
		try {
			properties.load (new FileReader (dirPath+"/Properties/"+ProjectName+".properties"));
		} catch (IOException e) { throw new RuntimeException (e);
		}
		Map<String, String> params = new HashMap<String, String> ();
		for (Map.Entry<Object, Object> each : properties.entrySet ()) {
			params.put (each.getKey ().toString(), each.getValue ().toString());
		}
		suite.setParameters (params);
	}

	public static void setDirPath (String dir_path) { 
		dirPath=dir_path;
	}

	public String getDriverPath (String property) {
		ProjectName=OpenAndCloseBrowser.P_Name;
		Properties properties = new Properties ();
		try {
			properties.load (new FileReader (dirPath+"/Properties/"+ProjectName+".properties"));
		} catch (IOException e) {
			throw new RuntimeException (e);
		}
		String driverPath = properties.getProperty(property);
		if(driverPath!=null) return driverPath;
		else throw new RuntimeException(property+" driverPath not specefied in the Configuration.properties file.");
	}


	public String getDriverPath (String projectName, String property) { 
		Properties properties = new Properties();
		try {

			properties.load (new FileReader (dirPath+"/Properties/"+projectName. toUpperCase ()+".properties"));

		} catch (IOException e) { 

			throw new RuntimeException (e);
		}
		String driverPath = properties.getProperty (property);

		if (driverPath!= null) return driverPath;

		else throw new RuntimeException ("driverPath not specified in the Configuration.properties file.");

	}

	public String getDriverPathFromGlobal (String property) {

		ProjectName = OpenAndCloseBrowser.P_Name;
		Properties properties = new Properties ();

		try {
			properties.load (new FileReader (dirPath+"/Properties/GLOBAL.properties")); 
		}catch (IOException e) {
			throw new RuntimeException (e);
		}

		String driverPath=properties.getProperty (property);
		if (driverPath!= null) return driverPath;
		else throw new RuntimeException ("driverPath not specified in the Configuration properties file.");

	}

	public boolean setProperty (String propertyName, String propertyValue) {
		ProjectName=OpenAndCloseBrowser.P_Name;
		String setValue="";

		try {

			PropertiesConfiguration config = new PropertiesConfiguration (dirPath+"/Properties/"+ProjectName+".properties");
			config.setProperty (propertyName, propertyValue);
			config.save ();
			Properties properties = new Properties ();
			properties.load (new FileReader (dirPath+"/Properties/"+ProjectName+".properties")); 
			setValue=properties.getProperty (propertyName) ;
		} catch (IOException e) {
			throw new RuntimeException (e);
		} catch (ConfigurationException e) { 
			e.printStackTrace();
		}
		if (setValue.equals (propertyValue)) return true;
		else throw new RuntimeException ("driverPath not specified in the Configuration.properties file.");
	}

	
	public boolean verifyIfPropertyIsPresent (String property) {

		ProjectName = OpenAndCloseBrowser.P_Name; 
		dirPath = OpenAndCloseBrowser.dir_Path;

		Properties properties = new Properties ();

		try {
			properties.load (new FileReader (dirPath+"/Properties/"+ProjectName+" properties")); 
		} 
		catch (IOException e) {
			throw new RuntimeException (e);
		}
		if (properties.getProperty (property) != null) {
			return true;	
		}
		else {
			return false;
		}
	}

	public void alter(List<XmlSuite> suites) {
		// TODO Auto-generated method stub
		
	}
}
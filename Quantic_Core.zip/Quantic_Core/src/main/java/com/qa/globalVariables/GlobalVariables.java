package com.qa.globalVariables;

import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.qa.Utils.ConfigFileReader;
import com.qa.genericLib.ActionDriver;
import com.qa.reporters.ExtentReporter;
import com.ugtf.prism.UGTFapi;

public class GlobalVariables {
	
	public static String HTMLFile;
	public static String testCaseName;
	public static ExtentReports extentReport;
	public static ExtentTest extentTest;
	public static ExtentTest scenarioTest;
	public static ExtentReports ScenarioReport;
	public static DesiredCapabilities caps;
	public static ConfigFileReader configFileReader;
	public static ExtentHtmlReporter extentHtmlReporter;
	public static ExtentHtmlReporter scenariotmlReporter;
	public static Properties properties;
	
	public static ExtentReporter quanticExtentReport;
	public static String reportStartTime = ActionDriver.getTimestamp().replace("/", "");
	public static String reportEndTime;
	public static UGTFapi trackerBDD;
	public static ThreadLocal<String> stepStartTimeTracker = new ThreadLocal<String>();
	public static HashMap<String, String> scenarioStatusMap = new HashMap<String, String>();
	
	
	public static ThreadLocal<WebDriver> Driver = new ThreadLocal<WebDriver>();
	
}
package com.qa.Utils;

public class ConfigFileReader {

}

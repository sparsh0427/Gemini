package com.qa.genericLib;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.xml.sax.SAXException;

public class ReportIntegration {

	public static String batchReporterFlag = "Y";
	
	public static void afterMethod(String method, String className) throws IOException, ParserConfigurationException, SAXException
	{
		// TODO Auto-generated method stub
		
	}
	
	public static void afterMethod(String method, String className, ITestResult result) throws IOException, ParserConfigurationException, SAXException
	{
		// TODO Auto-generated method stub
		
	}

	public static void beforeSuite(String projectName, String dirPath) {
		// TODO Auto-generated method stub
		
	}

	public static void aftersuite(ITestContext ctx) {
		// TODO Auto-generated method stub
		
	}

	public static void beforeMethod(String name, String string) throws IOException {
		// TODO Auto-generated method stub
		
	}

}

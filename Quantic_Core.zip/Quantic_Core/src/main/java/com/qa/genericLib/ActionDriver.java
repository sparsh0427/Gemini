package com.qa.genericLib;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.globalVariables.GlobalVariables;
import com.qa.listeners.PropertyInjectorListener;
import com.qa.reporters.BatchReporter;
import com.qa.reporters.ExtentReporter;

public class ActionDriver extends GlobalVariables {

		String commonPath = System.getProperty ("user.dir");
		long time = 40;
		public static String dirPath;
		public static SimpleDateFormat sdf;

		// public static List<Exception> exceptionList= new ArrayList<Exception>();


		public static void catchBlock (Exception e) {
			try {
				e.printStackTrace();
			 } catch (Exception exception) {
				e.printStackTrace();
			}
		}
		
		public void implicitwait () {
			Driver.get().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		
		public static final void dateformat() {
			sdf = new SimpleDateFormat ("dd_MMM yyyy_hh_mm_ssaa");
		}

		public void waitForElement(By loc) {
			try {
				WebDriverWait wait = new WebDriverWait (Driver.get(), time);
				wait.until(ExpectedConditions.presenceOfElementLocated (loc));
			} catch (NoSuchElementException e) {
				catchBlock (e) ;
			} catch (Exception e) {
				catchBlock (e);
			}
		}
		public void waitUntilPresenceOfElement (By loc) {
			try {
				WebDriverWait wait = new WebDriverWait (Driver.get(), time); 
				wait.until(ExpectedConditions.presenceOfElementLocated (loc));
			} catch (Exception e) {
				catchBlock (e);
			}
		}
		
		public void waitUntilPresenceOfElementShortTime (By loc) {
			try {
				WebDriverWait wait = new WebDriverWait (Driver.get(), 20);
				wait.until(ExpectedConditions.presenceOfElementLocated (loc));
				} catch (Exception e) {
					catchBlock(e);
				}
			
			}

		public void waitUntilElementEnabled (By loc) {
			try {
				WebDriverWait wait = new WebDriverWait (Driver.get(), 20);
				wait.until(ExpectedConditions.elementToBeClickable (loc));
			} catch (Exception e) {
				catchBlock (e);
			}
		}

		public void waitForAlert () {
			try {
				WebDriverWait wait = new WebDriverWait (Driver.get (), time);
				wait.until(ExpectedConditions.alertIsPresent());
			}catch (Exception e) {
				catchBlock(e);
			}
		}

		public void type (By loc, String value, String methodname, String description, String steps) {
				String status;
				try {
					waitForElement (loc);
					WebElement element = Driver.get ().findElement (loc);
					element.clear();
					element.sendKeys (value);
					if (element.isEnabled () == true) {
						status="PASS";
						BatchReporter.appendrow(methodname, status, description, steps, getTime(), getScreenShot (""));
					}else {
						status = "FAIL";
						BatchReporter.writeFailInReport (methodname, status, description, "Failed to type", getScreenShot (""));
					}
				}catch (Exception e) {
					catchBlock(e);
				}
		}
					
		public String getTime() {
			Date date = new Date();
			SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
			String time = sdfTime.format(date).toString();
			return time;
		}

		public String getScreenShot(String stepNo) {
			if(ReportIntegration.batchReporterFlag.equalsIgnoreCase("Y")) {
				stepNo = stepNo.replaceAll("\\s","");
				File location = new File(BatchReporter.testFolder);
				Date date = new Date();
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_ssaa");
				String screenshotName = location + "\\Screenshot\\" + stepNo + "_" + dateFormat.format(date) + ".png";
				File src = ((TakesScreenshot) Driver.get()).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src, new File(screenshotName));
				}catch (IOException e) {
					e.printStackTrace();
				}
				return screenshotName;
			}else {
				return "";
			}
		}

		public void type (By loc, String value) {
			try {
				waitForElement (loc);
				WebElement element = Driver.get().findElement (loc);
				element.clear();
				element.sendKeys (value);
			} catch (Exception e) {
				catchBlock (e);
			}
	}

	public void refresh () {
		Driver.get() .navigate().refresh();
	}

	public void refreshAndAcceptAlert() {
		try {
			Driver.get().navigate().refresh ();
			waitForAlert ();
			acceptAlert();
		} catch (Exception e) {
			catchBlock (e);
		}
	}

	public void doubleClickOnElement (By loc) {
		try {
			waitForElement (loc);
			WebElement element = Driver.get ().findElement (loc);
			Actions action = new Actions (Driver.get());
			action.moveToElement(Driver.get().findElement(loc)).doubleClick(element).build().perform();
		} catch (Exception e) {
			catchBlock (e);
		}
	}
	
	public void clickAndHoldandMoveToElement (By loc, By moveToElement) {
		try {
			waitForElement (loc);
			WebElement element = Driver.get ().findElement (loc);
			WebElement elementMoveTo = Driver.get ().findElement (moveToElement); Actions action = new Actions (Driver.get());
			action.clickAndHold (element).moveToElement (elementMoveTo) .build() .perform();
		} catch (Exception e) {
			catchBlock (e);
		}
	}

	public void moveToElementAndPaste (By loc, String controlAction) {
		try {
			waitUntilPresenceOfElementShortTime (loc);
			Actions action = new Actions (Driver.get());
		} catch (Exception e) { 
			catchBlock (e);
		}
	}
	
	public static String setDirPath (String dir_path) {
		dirPath = dir_path;
		return dirPath;
	}

	public void doubleClickHandsOnTable (By loc, String value) {
		try {
			waitForElement (loc);
			WebElement element = Driver.get ().findElement (loc);
			Actions action = new Actions (Driver.get());
			action.moveToElement (Driver.get ().findElement (loc)).doubleClick (element).sendKeys (value) .build() .perform();
		}catch (Exception e) { 
			catchBlock (e);
		}
	}
		
	public void click (By loc) {
		try {
			waitForElement (loc);
			WebElement element = Driver.get ().findElement (loc);
			element.click();
			System.out.println("clicked");
		} catch (UnhandledAlertException f) {
			try {
				Alert alert = Driver.get ().switchTo () .alert ();
				alert.accept();
				System.out.println("clicked catch");
			}catch (NoAlertPresentException e) {
				catchBlock (e);	
			} 
			}catch (Exception e) {
				e.printStackTrace();
				catchBlock (e);
				System.out.println("clicked ex");
			}
		}
			
	public void click (By loc, String methodname, String description, String steps) {
		String status;
		try {
			waitForElement (loc);
			WebElement element = Driver.get ().findElement (loc);
			element.click();
			if (element.isEnabled () == true) {
				status="PASS";
				BatchReporter.appendrow(methodname, status, description, steps, getTime(), getScreenShot (""));
			} else {
			status = "FAIL";
			BatchReporter.writeFailInReport (methodname, status, description, "Element to be clicked is either disabled or not visible", getScreenShot (""));
			
			}

		} catch (UnhandledAlertException f) {

			try {
			Alert alert = Driver.get ().switchTo ().alert (); // String alertText = alert.getText();
			// System.out.println("Alert data: + alertText); 
			alert.accept();
			} catch (NoAlertPresentException e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			catchBlock (e) ;
		}
	}
						
	
	public String typeClickGetErrorMagTxt (By typeLoc, String typeValue, By clickLoc, By clickBtnOnAlertMessage, By errorMsgTxt, String methodname, String steps, String description, String stepno) throws InterruptedException, IOException {
		try {
			String status;
			waitForElement (typeLoc);
			WebElement textbox = Driver.get ().findElement (typeLoc);
			textbox.clear();
			textbox.sendKeys (typeValue);
			waitForElement (clickLoc);
			WebElement clickElement = Driver.get().findElement(clickLoc); 
			clickElement.click();
			Thread.sleep (3500);
			String errorSummaryMag = getElementText(errorMsgTxt);
			boolean result = isElementPresent(errorMsgTxt);
			if (result == true) {
				status = "PASS";
				BatchReporter.appendrow (methodname, status, steps, "Message Text:-<br>" + errorSummaryMag, getTime(),getScreenShot(stepno));
			} else {
				status = "FAIL";
				BatchReporter.writeFailInReport (methodname, status, description, "Failed", getScreenShot (""));
			}
			click(clickBtnOnAlertMessage);
			Thread.sleep (2500);
			return status;
	
			} catch (Exception e) {
				catchBlock (e);
				return "FAIL";
			}
	}
				
	public void getClipboardContents() throws UnsupportedFlavorException, IOException {
		try {
		Toolkit toolkit = Toolkit.getDefaultToolkit ();
		Clipboard clipboard = toolkit.getSystemClipboard();
		String result = (String) clipboard.getData (DataFlavor.stringFlavor);
		System.out.println("lenghth of string: " + result.length());
		} catch (Exception e) {
		catchBlock (e);
		}
	}
		
	public String typeClickGetErrorMsgTxt1 (By typeLoc, String typeValue, By clickLoc, By clickBtnOnAlertMessage,
		By errorMsgTxt, String methodname, String steps, String description, String stepno)
		throws InterruptedException, IOException {
		
		try {
			String status;
			waitForElement(typeLoc);
			WebElement textbox = Driver.get().findElement(typeLoc);
			textbox.clear();
			textbox.sendKeys (typeValue);
			waitForElement (clickLoc);
			WebElement clickElement = Driver.get ().findElement (clickLoc);
			clickElement.click();
			Thread.sleep (3500);
			boolean result = isElementPresent(clickLoc); 
			if (result = true) {
				status =" PASS";
				BatchReporter.appendrow (methodname, status, steps, description, getTime(), getScreenShot (stepno));
			}
			else {
				status= "FAIL";
				BatchReporter.writeFailInReport (methodname, status, description, "Failed", getScreenShot (""));
			}
			Thread. sleep(2500);
			return status;
		} catch (Exception e) {
			catchBlock (e);
			return "FAIL";
		}
	}
		
		public String typeClickGetErrorMsgTxtAndCompareAlertText (By typeLoc, String typeValue, By clickLoc, By clickBtnOnAlertMessage, By errorMsgTxt, String methodname, String steps, String description,
				String stepno, String expected) throws InterruptedException, IOException {
			
			try {
				String status;
				waitForElement (typeLoc);
				WebElement textbox = Driver.get ().findElement (typeLoc);
				textbox.clear();
				textbox.sendKeys (typeValue);
				waitForElement (clickLoc);
				WebElement clickElement = Driver.get ().findElement (clickLoc);
				clickElement.click();
				Thread.sleep (3500);
				String errorSummaryMag = getElementText(errorMsgTxt);
				boolean result = isElementPresent(errorMsgTxt);
				if (result == true) {
					status = "PASS";
					BatchReporter.appendrow (methodname, status, steps, "Message Text:-<br>" + errorSummaryMag, getTime(),getScreenShot (stepno));
				}
				else {
				status = "FAIL";
				BatchReporter.writeFailInReport (methodname, status, description, "Failed", getScreenShot (""));
				}
				Thread.sleep (2500);
				click (clickBtnOnAlertMessage);
				Thread.sleep(2500);
				return status;
			} catch (Exception e){
				catchBlock(e);
				return "FAIL";
			}
		}
						
		public boolean isElementPresent(By loc) {
			try {
				waitForElement(loc);
				WebElement element = Driver.get().findElement(loc);
				Boolean res = element.isDisplayed();
				return res;
			}catch (Exception e) {
				return false;
			}
		}

		public String getElementText(By loc) {
			try {
				waitForElement(loc);
				WebElement element = Driver.get().findElement(loc);
				return element.getText();
			}catch (Exception e) {
				catchBlock(e);
				return "FAIL";
			}
		}
		
		public String getElementText(By loc, int fieldLoadTimeout) {
			try {
				WebDriverWait wait = new WebDriverWait(Driver.get(), fieldLoadTimeout);
				wait.until(ExpectedConditions.presenceOfElementLocated(loc));
				WebElement element = Driver.get().findElement(loc);
				return element.getText();
			}catch (Exception e) {
				catchBlock(e);
				return "FAIL";
			}
		}

		public void hoverAndClick (By locToHover, By locToClick) {
				try {
					waitForElement (locToHover);
					WebElement elementToHover = Driver.get().findElement (locToHover);
					WebElement elementToClick = Driver.get ().findElement (locToClick);
					Actions action = new Actions (Driver.get());
					action.moveToElement (elementToHover).click (elementToClick) .build().perform();
				} catch (Exception e) {
				catchBlock (e);
				}
			}
	
		public boolean compareTwoStrings (String actual, String expected) {
			try {
				boolean result;
				if (actual.equalsIgnoreCase (expected)) {
					result = true;
				} else {
					result = false;
				}
				return result;
			} catch (Exception e) {
				catchBlock (e);
			}
			return false;
		}
		
		public boolean compareTwoStrings (String actual, String expected, String methodname, String description,String steps) {
				String status;
				try {
					boolean result;
					
					if (actual.equalsIgnoreCase (expected)) {
						result = true;
						status="PASS";
						BatchReporter.appendrow (methodname, status, description, steps, getTime(), getScreenShot (""));
				} else {
					result = false;
					status = "FAIL";
					BatchReporter.writeFailInReport(methodname, status, description, "Failed", getScreenShot (""));
				}
					return result;
				} catch (Exception e) {
					catchBlock (e);
					return false;
				}
			}
					
					
		public void clickAlertAndgetErrorMessage (By clickXpath, By errorMsgXpath) throws InterruptedException {
				try {
					Thread.sleep(1500);
					getElementText(errorMsgXpath);
					click (clickXpath);
					Thread. sleep (1500);
				} catch (UnhandledAlertException f) {
					try {
						Alert alert = Driver.get().switchTo().alert();
						String alertText =  alert.getText (); 
						System.out.println("Alert data: " + alertText);
						alert.accept();
					}catch (NoAlertPresentException e) {
					e.printStackTrace();
					}
				} catch (Exception e) {
					catchBlock(e);
				}
			}

				
		public void keydown (By loc) {
			try {
				waitForElement (loc);
				WebElement element = Driver.get ().findElement (loc); 
				Actions act = new Actions (Driver.get());
				act.moveToElement (element).keyDown(Keys.CONTROL).perform();
			}
			catch (Exception e) { 
				catchBlock (e);
			}
		}
		
		public void scrollBy(By loc) {
			try {
				while(!isElementPresent(loc) == true) {
					JavascriptExecutor js = (JavascriptExecutor) Driver.get();
					js.executeScript("window.scrollBy(250,0)", "");
				}
			}
			catch(Exception e) {
				catchBlock(e);
			}
		}
		
		public void scrollTillBottom() {
			try {
				Actions actions = new Actions(Driver.get());
				actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectFromDropdown(By loc, String value) {
			try {
				WebElement element = Driver.get().findElement(loc);
				Select s = new Select(element);
				System.out.println("DD values:" + s);
				s.selectByValue(value);
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectCronusEnv(String value) {
			try {
				WebElement element = Driver.get().findElement(By.xpath("//*[@id='ddlCommanEnvironment']"));
				Select s = new Select(element);
				System.out.println("DD values" + s);
				s.selectByValue(value);
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectFromDropDownByIndex(By loc, int index) {
			try {
				WebElement element = Driver.get().findElement(loc);
				Select s = new Select(element);
				s.selectByIndex(index);
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectFromDropdown(By loc, String value, String methodname, String description, String steps) {
			try {
			String status;
			WebElement element = Driver.get().findElement(loc);
			Select s = new Select(element);
			s.selectByValue(value);
			if(element.isEnabled() == true) {
				status = "PASS";
				BatchReporter.appendrow(methodname, status, description, steps, getTime(), getScreenShot(""));
			}else {
				status = "FAIL";
				BatchReporter.writeFailInReport(methodname, status, description, "Failed to select", getScreenShot(""));
			}
			} catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectFromDropdownByIndex(By loc, int index, String methodname, String description, String steps) {
			try {
				String status;
				WebElement element = Driver.get().findElement(loc);
				Select s = new Select(element);
				s.selectByIndex(index);
				if(element.isEnabled() == true) {
					status = "PASS";
					WebElement option = s.getFirstSelectedOption();
					String defaultItem = option.getText();
					BatchReporter.appendrow(methodname, status, "Select status:" + defaultItem, steps, getTime(), getScreenShot(""));
				}else {
					status = "FAIL";
					BatchReporter.appendrow(methodname, status, description, "Failed to select", getTime(), getScreenShot(""));
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectFromDropdownByVisibleText(By loc, String value) {
			try {
				WebElement element = getWebElemet(loc, 15);
				Select s = new Select(element);
				s.selectByVisibleText(value);
				if(s.getFirstSelectedOption().getText().contains(value))
					System.out.println("Selected value:" + value + "from dropdown.");
				else
					System.out.println("Unable to select value:" + value + "from dropdown.");
			}catch (Exception e) {
				catchBlock(e);
			}
		}

		public WebElement getWebElemet(By byLocator, int loadTimeout) {
			WebElement element = null;
			WebDriverWait wait = new WebDriverWait(Driver.get(), loadTimeout);
			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
				element = Driver.get().findElement(byLocator);
			}catch (Exception exception) {
				element = null;
			}
			return element;
		}
		
		public void selectFromDropdownByVisibleText(By loc, String value,String methodname,String description, String steps) {
			try {
				String status;
				WebElement element = Driver.get().findElement(loc);
				Select s = new Select(element);
				s.selectByVisibleText(value);
				if(element.isEnabled() == true) {
					status = "PASS";
					BatchReporter.appendrow(methodname, status, description, steps, getTime(), getScreenShot(""));
				} else {
					status = "FAIL";
					BatchReporter.writeFailInReport(methodname, status, description, "Failed to select",  getScreenShot(""));
				}
			} catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public String getDDVisibleText(By loc) {
			WebElement element = Driver.get().findElement(loc);
			Select s = new Select(element);
			return s.getFirstSelectedOption().getText();
		}
		
		public boolean textIsEqualTo(By loc, String value) {
			waitForElement(loc);
			WebElement element = Driver.get().findElement(loc);
			return element.getText().equalsIgnoreCase(value);
		}
		
		public void reporterAppendRow(String status, String methodname, String description, String steps) throws IOException  {
			BatchReporter.appendrow(methodname, status, description, steps, getTime(), getScreenShot(""));
		}
		
		public void writeFailinReport(String status, String methodname, String description, String steps) throws IOException  {
			BatchReporter.writeFailInReport(methodname, status, description, steps, getScreenShot(""));
		}
		
		public void isElementPresent(By loc, String methodname, String description, String steps) {
			try {
				String status;
				waitForElement(loc);
				WebElement element = Driver.get().findElement(loc);
				Boolean res = element.isDisplayed();
				if(res == true) {
					status = "PASS";
					BatchReporter.appendrow(methodname, status, description, steps, getTime(), getScreenShot(""));
					
				}else {
					status = "FAIL";
					BatchReporter.writeFailInReport(methodname, status, description, "Element is not visible", getScreenShot(""));
				}
			} catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public boolean isElementEnabled(By loc) {
			try {
				waitForElement(loc);
				WebElement element = Driver.get().findElement(loc);
				Boolean res = element.isEnabled();
				return res;
			}catch (Exception e) {
				catchBlock(e);
				return false;
			}
		}
		
		public void isElementEnabled(By loc, String methodname, String description, String steps) {
			try {
				String status;
				waitForElement(loc);
				WebElement element = Driver.get().findElement(loc);
				Boolean res = element.isEnabled();
				if(res == true) {
					status = "PASS";
					BatchReporter.appendrow(methodname, status,description, steps, getTime(), getScreenShot(""));
				} else {
					status = "FAIL";
					BatchReporter.writeFailInReport(methodname, status,description, "Element is not visible",getScreenShot(""));
				}
			} catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public String getTitle() {
			return Driver.get().getTitle();
		}
		
		public void switchToAlert() {
			try {
				waitForAlert();
				Driver.get().switchTo().alert();
			} catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void switchToiFrame(String id) {
			try {
				Driver.get().switchTo().frame(id);
			} catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void closeAlert() {
			try {
				waitForAlert();
				Driver.get().switchTo().alert().dismiss();
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void acceptAlert(){
			try {
				waitForAlert();
				Driver.get().switchTo().alert().dismiss();
			} catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public String getAlertText() {
			try {
				return Driver.get().switchTo().alert().getText();
			} catch (Exception e) {
				catchBlock(e);
				return e.getMessage();
			}
		}
		
		public String getValue(By loc) {
			try {
				waitForElement(loc);
				WebElement element = Driver.get().findElement(loc);
				return element.getAttribute("value");
			}catch(Exception e) {
				catchBlock(e);
				new Throwable("Failed to get value");
				return e.getMessage();
			}
		}
		
		public boolean isAttributePresent(By loc) throws java.util.NoSuchElementException {
			Boolean result = false;
			try {
				waitForElement(loc);
				WebElement element = Driver.get().findElement(loc);
				String value = element.getAttribute("href");
				if(value != null) {
					result = true;
				}
			}catch (NoSuchElementException e) {
				result = false;
			}catch (Exception e) {
				
			}
			return result;
		}
		
		public boolean isAttributePresent(By loc, String methodname, String description, String steps) throws java.util.NoSuchElementException, IOException {
			waitForElement(loc);
			WebElement element = Driver.get().findElement(loc);
			Boolean result = false;
			String status;
			try {
				String value = element.getAttribute("href");
				if(value != null) {
					result = true;
					status = "PASS";
					BatchReporter.appendrow(methodname, status,description, steps, getTime(), getScreenShot(""));
				}
			} catch (NoSuchElementException e) {
				result = false;
				status = "FAIL";
				BatchReporter.writeFailInReport(methodname, status,description,"Element is not present on the page" , getScreenShot(""));
			}catch (Exception e) {
				catchBlock(e);
			}
			return result;
		}
		
		public void selectRadioButton(By loc, String value) {
			try {
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option: elements) {
					System.out.println((option.getText()));
					if(option.getText().equalsIgnoreCase(value)) {
						option.click();
						break;
					}
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectRadioButton(By loc, String value, String methodname, String description, String steps) throws IOException {
			try {
				String status;
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option: elements) {
					System.out.println((option.getText()));
					if(option.getText().equalsIgnoreCase(status)) {
						option.click();
						if(option.isEnabled() == true) {
							status = "PASS";
							BatchReporter.appendrow(methodname, status,description, steps, getTime(), getScreenShot(""));
						}else {
							status = "FAIL";
							BatchReporter.writeFailInReport(methodname, status,description, "Element is not enabled", getScreenShot(""));
						}
						break;
					}
				}
			} catch(Exception e) {
				catchBlock(e);
			}
		}
		
		public int countNoofElements (By loc) {
			try {
				int count = 0;
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				count = elements.size();
				return count;
			}catch (Exception e) {
				catchBlock(e);
				return 0;
			}
		}
		
		public void selectFromChbList(By loc, String value) {
			try {
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option : elements) {
					if(option.getText().equalsIgnoreCase(value)) {
						option.click();
						break;
					}
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectFromChbList(By loc, String value, String methodname, String description, String steps ) {
			try {
				String status;
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option : elements) {
					if(option.getText().equalsIgnoreCase(value)) {
						option.click();
						if(option.isEnabled() == true) {
							status = "PASS";
							BatchReporter.appendrow(methodname, status,description, steps, getTime(), getScreenShot(""));
						}else {
							status = "FAIL";
							BatchReporter.writeFailInReport(methodname, status,description, "Failed to type", getScreenShot(""));
						}
						break;
					}
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectFromChbListByTextContext(By loc, String value) {
			try {
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option: elements) {
					System.out.println("Values: "+ option.getAttribute("textContext"));
					if(option.getAttribute("textContext").equalsIgnoreCase(value)) {
						option.click();
						break;
					}
				}
			}catch(Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectromChbListByTextContext (By loc, String value, String methodname, String description, String steps) throws IOException {
			String status;
			try {
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option : elements) {
					System.out.println("Values: " + option.getAttribute("textContext"));
					if(option.getAttribute("textContext").equalsIgnoreCase(value)) {
						option.click();
						if(option.isEnabled() == true) {
							status = "PASS";
							BatchReporter.appendrow(methodname, status,description, steps, getTime(), getScreenShot(""));
						}else {
							status = "FAIL";
							BatchReporter.writeFailInReport(methodname, status,description,"Failed to type", getScreenShot(""));
						}
						break;
					}
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectAllChbinList(By loc) {
			try {
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option : elements) {
					option.click();
				}
			}catch (Exception e) {
				catchBlock(e);
			}
		}
		
		public void selectAllChbinList(By loc, String methodname, String description, String steps) {
			try {
				String status;
				waitForElement(loc);
				List<WebElement> elements = Driver.get().findElements(loc);
				for(WebElement option : elements) {
					option.click();
					if(option.isEnabled() == true) {
						status = "PASS";
						BatchReporter.appendrow(methodname, status,description, steps, getTime(), getScreenShot(""));
					}else {
						status = "FAIL";
						BatchReporter.writeFailInReport(methodname, status,description, "Failed to type", getScreenShot(""));
					}
					
				}
			}catch(Exception e) {
				catchBlock(e);
			}
		}

}

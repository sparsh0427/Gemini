package com.qa.genericLib;

public class MainClass {

	public static String batch;

}

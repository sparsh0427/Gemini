package com.qa.genericLib;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;	
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.xml.sax.SAXException;

import com.qa.dataProviders.CommonDataProvider;
import com.qa.globalVariables.GlobalVariables;


public class OpenAndCloseBrowser extends GlobalVariables {

	public static String P_Name,  dir_Path, suiteName, tag_name;
	public static ThreadLocal<String> Methodname = new ThreadLocal<String>();
	public static ThreadLocal<String> className = new ThreadLocal<String>();
	long time;
	
	public static void suiteSetUp(String browser, String baseURL, String classname) throws Exception {
		Driver.set(BrowserInit.initBrowser(browser, baseURL, classname, dir_Path));
		Driver.get().manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		Driver.get().manage().window().maximize();
		Driver.get().get(baseURL);
		className.set(classname);
		CommonDataProvider.getClassToRunFlag(className.get());		
	}
	
	public static WebDriver getInstance() {
		return Driver.get();
	}
	
	@Parameters({"ProjectName","dirPath"})
	@BeforeSuite
	public static void beforeSuite(String ProjectName, String dirPath) throws IOException {
		P_Name = ProjectName;
		P_Name = P_Name.replaceAll("\\s", "");
		suiteName = MainClass.batch;
		dir_Path = System.getProperty("user.dir");
		ReportIntegration.beforeSuite(ProjectName, dirPath);
	}
	
	@BeforeMethod()
	public static void beforeMethod(Method method) throws IOException{
		Methodname.set(method.getName());
		ReportIntegration.beforeMethod(method.getName(), className.get());
	}
	
	@AfterMethod
	public void afterMethod(ITestResult result) throws IOException, ParserConfigurationException, SAXException {
		time = result.getEndMillis() - result.getStartMillis();
		ReportIntegration.afterMethod(Methodname.get(), className.get(), result);
	}
	
	@AfterClass
	public static void suiteTearDown() {
		try {
			if (Driver.get() != null) {
				Driver.get().close();
			}}catch (Exception e) {
				
		}
	}
	
	@AfterSuite
	public static void afterSuite(ITestContext ctx) throws Exception {
		ReportIntegration.aftersuite(ctx);
		GlobalVariables.trackerBDD.endExecution();
	}
	
}

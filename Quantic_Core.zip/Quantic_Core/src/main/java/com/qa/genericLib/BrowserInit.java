package com.qa.genericLib;

import java.net.URL;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.qa.globalVariables.GlobalVariables;
import com.qa.listeners.PropertyInjectorListener;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserInit extends GlobalVariables {

	
	public static WebDriver initBrowser (String browser, String baseURL, String classname, String dir_Path) throws Exception {
			WebDriver driver;
			ChromeOptions chromeOptions = new ChromeOptions();
			
			switch (browser.toLowerCase()) {
			case "firefox":
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				break;
			case "chrome":
				WebDriverManager.chromedriver().setup();
				chromeOptions = (new ChromeOptions()).setHeadless(false).setPageLoadStrategy(PageLoadStrategy.NORMAL);
				chromeOptions.addArguments("--no-sandbox", "--window-size-1920, 1200", "--ignore-certificate-error"); 
				chromeOptions.addArguments("-start-maximized");
				chromeOptions.addArguments("--disable-extensions"); 
				chromeOptions.addArguments("--disable-dev-shm-usage"); 
				chromeOptions.addArguments ("--verbose");
				chromeOptions.setExperimentalOption ("useAutomationExtension", false);
				System.out.println("CHROME SET UP DONE");
				driver = new ChromeDriver(chromeOptions);
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				break;
			case "chrome10":
				WebDriverManager.chromedriver().setup();
				chromeOptions.setExperimentalOption("useAutomation Extension", false);
				chromeOptions.addArguments("atart-maximized");
				driver = new ChromeDriver(chromeOptions);
				break;
			case "ie":
				WebDriverManager.iedriver().setup();
				caps = DesiredCapabilities. internetExplorer();
				caps.setCapability (InternetExplorerDriver. IE_ENSURE_CLEAN_SESSION, true);
				caps.setCapability (InternetExplorerDriver. IGNORE_ZOOM_SETTING, true);
				caps.setCapability (InternetExplorerDriver. INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				driver = new InternetExplorerDriver();
				break;
			case "headless":
				WebDriverManager.chromedriver().setup();
				chromeOptions.setHeadless (true);
				chromeOptions.addArguments ("window-size=1200x600"); 
				driver = new ChromeDriver(chromeOptions);
				break;
			case "edge":
				WebDriverManager.edgedriver().setup();
				caps = DesiredCapabilities.edge();
				caps.setBrowserName (browser);
				caps.setPlatform (Platform. WIN10);
				driver = new EdgeDriver();
				break;
			case "safari":
				driver = new SafariDriver ();
				break;
			case "grid":
				WebDriverManager.chromedriver().setup();
				PropertyInjectorListener propertyInjectorListener = new PropertyInjectorListener();
				DesiredCapabilities capa = DesiredCapabilities.chrome ();
				capa.setBrowserName ("chrome");
				capa.setPlatform (Platform. WINDOWS);
				driver = new RemoteWebDriver (new URL (propertyInjectorListener.getDriverPathFromGlobal ("nodeURL")), capa);
				break;
			default:
				WebDriverManager.chromedriver().setup();
				chromeOptions.addArguments("window-size=1200x600");
				driver = new ChromeDriver(chromeOptions);
				break;
			}
			return driver;
	}
	
	public static void launch_browser() throws Exception{
		PropertyInjectorListener property = new PropertyInjectorListener();
		String browser,URL;
		System.out.print("in before hook");
		browser = property.getDriverPath("browser");
		URL = property.getDriverPath("baseURL");
		OpenAndCloseBrowser.suiteSetUp(browser, URL, "");
	}
}
	
						
						
						